import bcrypt from 'bcrypt';
import express from 'express';
import { sessionStorage } from './server.js'
let newSession = async (req, res, next) => {
    if (!req.cookies.sessionId) {
        let sessionId = await bcrypt.hash(`${Date.now()}`, 10);
        let session = getSession(req, res);
        req.session = session;
        sessionStorage.push({ id: sessionId, session: session });
        res.cookie('sessionId', sessionId);
    } else {
        let existingSession = null;
        for (let i = 0; i < sessionStorage.length; i++) {
            if (sessionStorage[i].id === req.cookies.sessionId) {
                existingSession = sessionStorage[i].session;
                break;
            }
        }
        if (existingSession) {
            req.session = existingSession;
        } else {
            let sessionId = await bcrypt.hash(`${Date.now()}`, 10);
            let session = getSession(req, res);
            req.session = session;
            sessionStorage.push({ id: sessionId, session: session });
            res.cookie('sessionId', sessionId);
        }
    }
    next();
};
/**
 * 
 * @param {express.Request} req 
 * @param {express.Response} res 
 * @returns 
 */
function getSession(req, res) {
    let destroy = () => {
        // let id = req.cookies.sessionId;
        // for (let i = 0; i < sessionStorage.length; i++) {
        //     if (sessionStorage[i].id === id) {
        //         sessionStorage[i].session = {
        //             id: sessionStorage[i].id,
        //             session: { cookie: sessionStorage[i].session.cookie }
        //         };
        //         break;
        //     }
        // }
        res.clearCookie('sessionId');
    };

    let obj = {
        cookie: {
            path: '/',
            expires: null
        },
        destroy
    };

    return obj;
}

export{newSession}
