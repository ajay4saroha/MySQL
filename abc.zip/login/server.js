import express from 'express'
import path from 'path'
import {newSession} from './middleware.js'
import cookieParser from 'cookie-parser'
let sessionStorage = []
const app= express()
app.use(cookieParser('helo knds'))
app.use(newSession)
app.set('view engine','ejs')
app.use(express.urlencoded({extended:true}))
app.use(express.json())


app.get('/logout', async (req,res)=>{
    try {
        await new Promise((resolve, reject) => {
            setTimeout(() => {
                resolve();
            }, 1000);
        })
        req.session.destroy();
    } catch (error) {
        console.log(error);
    }
    // req.session.destroy()
    res.redirect('/')
})


app.get('/login',(req,res)=>{
    if(req.session.isLoggedIn){
        return res.redirect('/dashboard')
    }
    else
    res.render('login');
})
app.post('/dashboard',(req,res)=>{
    if(req.body.username==='admin' && req.body.password==='123456'){
        req.session.isLoggedIn = true
        req.session.username = req.body.username
        req.session.password = req.body.password
        res.render('dashboard',{username:req.session.username})
    }
    else{
        console.log('Invalid User and Password');
        res.redirect('/');
    }
})
.get('/dashboard',(req,res)=>{
    if(req.session.isLoggedIn){
        res.render('dashboard',{username:req.session.username})
    }
    else{
        res.redirect('/');
    }
})

app.get('*',(req,res)=>{
    if(req.session.isLoggedIn){
        res.redirect('/dashboard')
        return
    }
    res.redirect('/login');
})
app.listen(4000,()=>console.log("SERVER STARTED"));
export{sessionStorage}
