let sessionStorage = []
import bcrypt from 'bcrypt';
class Session {
    static async createSession(req, res) {
        let sessionId = await bcrypt.hash(`${Date.now()}`, 10);
        let session = this.getSessionTemplate();
        req.session = session;
        sessionStorage.push({ id: sessionId, session: session });
        res.cookie('sessionId', sessionId);
    }

    static getSessionTemplate() {
        return {
            cookie: {
                path: '/',
                expires: null
            }
        };
    }

    static async newSession(req, res, next) {
        if (!req.cookies.sessionId) {
            this.createSession(req, res);
        } else {
            let existingSession = sessionStorage.find(item => item.id === req.cookies.sessionId);
            if (existingSession) {
                req.session = existingSession.session;
            } else {
                this.createSession(req, res);
            }
        }
        next();
    }

    static destroySession(req, res, next) {
        if (req.cookies.sessionId) {
            sessionStorage = sessionStorage.filter(item => item.id !== req.cookies.sessionId);
            res.clearCookie('sessionId');
        }
        next();
    }
}

export default Session;
